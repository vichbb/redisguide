#!/usr/bin/env
firewall-cmd --zone=public --add-port=6379/tcp --permanent
firewall-cmd --zone=public --add-port=6380/tcp --permanent
firewall-cmd --zone=public --add-port=26379/tcp --permanent
firewall-cmd --zone=public --add-port=26380/tcp --permanent
firewall-cmd --zone=public --add-port=26381/tcp --permanent
firewall-cmd --zone=public --add-port=1111/tcp --permanent
firewall-cmd --zone=public --add-port=7778/tcp --permanent
firewall-cmd --zone=public --add-port=9998/tcp --permanent
firewall-cmd --zone=public --add-port=5555/tcp --permanent
firewall-cmd --reload
echo 'sleep5秒'
sleep 5
firewall-cmd --zone=public --list-ports

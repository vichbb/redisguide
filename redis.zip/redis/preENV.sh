#!/usr/bin/env

#安装gcc套装
# yum   install cpp
# yum   install binutils
# yum   install glibc
# yum   install glibc-kernheaders
# yum   install glibc-common
# yum   install glibc-devel
# yum   install gcc
# yum   install make
#升级gcc
# yum   -y install centos-release-scl
# yum   -y install devtoolset-9-gcc devtoolset-9-gcc-c++ devtoolset-9-binutils
# scl   enable devtoolset-9 bash
#设置永久升级：
# echo   "source /opt/rh/devtoolset-9/enable" >>/etc/profile

#下载redis
# yum install -y  wget
# wget   https://download.redis.io/releases/redis-6.0.8.tar.gz
# tar   xzf redis-6.0.8.tar.gz
# cd   redis-6.0.8
# 编译出错时，清出编译生成的文件
#make distclean
# 编译安装到指定目录下
# make   PREFIX=/usr/local/redis install
# 卸载
#make uninstall

tar -xzvf redis-6.0.8_make.tar.gz
cd   redis-6.0.8/src
mkdir -p /usr/local/redis/bin
cp redis-benchmark  redis-check-aof  redis-check-rdb  redis-cli  redis-sentinel  redis-server  /usr/local/redis/bin

#配置环境变量
# vim /etc/profile
# cd ~
# vim .bashrc
# export  REDIS_HOME=/usr/local/redis
# export  PATH=$PATH:$REDIS_HOME/bin
# source /etc/profile

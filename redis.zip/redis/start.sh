#!/usr/bin/env
role='master'
masterIp=127.0.0.1
masterPort=6379
passWord=password1
CRTDIR=$(pwd)
redisPortArray=(6379 6380)
sentPortArray=(26379 26380 26381)
dirArr=("${CRTDIR}/logs" "${CRTDIR}/pid" "${CRTDIR}/sent/logs" "${CRTDIR}/sent/logs" "${CRTDIR}/sent/pid" "${CRTDIR}/sent/tmp" "${CRTDIR}/sent/tmp/26379" "${CRTDIR}/sent/tmp/26380" "${CRTDIR}/sent/tmp/26381")
for element in ${dirArr[*]}; do
  echo $element
  if [ ! -d $element ]; then
    echo '创建:'$element
    mkdir $element
  fi

done

echo '5秒后启动redis'
sleep 5
for element in ${redisPortArray[*]}; do
  tmp=$CRTDIR'/redis_'$element'.conf'
  echo $tmp
  sed -i "/^slaveof/c slaveof $masterIp $masterPort" $tmp
  sed -i "/^requirepass/c requirepass $passWord" $tmp
  sed -i "/^masterauth/c masterauth $passWord" $tmp
  if [[ "$role" = "master" ]]; then
    #statements
    echo 'master节点'
    if [[ "$element" = "6379" ]]; then
      #statements
      echo 'master节点6379'
      redis-server $tmp
    fi
  else
    if [[ "$element" != "6379" ]]; then
      #statements
      echo 'slave节点非6379'
      redis-server $tmp
    fi
  fi

  echo '启动完毕'
done
echo '等待5秒'
sleep 5

redisCount=$(ps -e | grep redis-server | wc -l)
echo 'redis数量:'$redisCount
if [[ $redisCount -ne 1 ]]; then
  echo 'redis数量异常,请检查!'
  exit
fi
echo 'redis部署完成'
echo '5秒后启动哨兵'
sleep 5
for element in ${sentPortArray[*]}; do
  tmp=$CRTDIR'/sent/sentinel-'$element'.conf'
  cp $CRTDIR'/sent/sentinel.conf' $tmp

  sed -i "/^sentinel auth-pass/c sentinel auth-pass mymaster $passWord" $tmp

  sed -i "/^port/c port $element" $tmp

  sed -i "/^sentinel monitor/c sentinel monitor mymaster $masterIp $masterPort 2" $tmp

  tmpLog=$CRTDIR'/sent/logs/redis-sentinel-'$element'.log'
  sed -i "/^logfile/c logfile ${tmpLog}" $tmp

  tmpPid=$CRTDIR'/sent/pid/redis-sentinel-'$element'.pid'
  sed -i "/^pidfile/c pidfile ${tmpPid}" $tmp

  tmpDir=$CRTDIR'/sent/tmp/'$element
  sed -i "/^dir/c dir ${tmpDir}" $tmp

  echo $tmp
  if [[ "$role" = "master" ]]; then
    #statements
    echo 'master节点'
    if [[ "$element" != "26381" ]]; then
      #statements
      echo 'master节点非26381节点端口'
      redis-sentinel $tmp
    fi
  else
    echo 'slave节点'
    if [[ "$element" = "26381" ]]; then
      #statements
      echo 'slave节点26381节点端口'
      redis-sentinel $tmp
    fi
  fi
  echo '启动完毕'
done
echo '等待5秒'
sleep 5

sentinelCount=$(ps -e | grep redis-sentinel | wc -l)
echo 'sentinel数量:'$sentinelCount
if [[ "$role" = "master" ]]; then
  #statements
  if [[ $sentinelCount -ne 2 ]]; then
    echo 'master节点sentinel数量异常,请检查!'
    exit
  fi
else
  if [[ $sentinelCount -ne 1 ]]; then
    echo 'slave节点数量异常,请检查!'
    exit
  fi
fi

echo 'sentinel部署完成'
